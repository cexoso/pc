angular.module('controller').controller('colorfulCtrl',['$scope',function(s){
    
}]);