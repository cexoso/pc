angular.module('controller').controller('queryCtrl',['$scope','$q',function(s,$q){
    
}]);