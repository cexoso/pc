angular.module('controller').controller('reapairProcessCtrl',['$scope','$rootScope','$timeout','mRepariNav',function(s,$rootScope,$timeout,mRepariNav){
    s.mRepariNav=mRepariNav;
}]);