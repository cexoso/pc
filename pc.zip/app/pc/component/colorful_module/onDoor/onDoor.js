angular.module('controller').controller('onDoorCtrl',['$scope',function(s){
    
}]);