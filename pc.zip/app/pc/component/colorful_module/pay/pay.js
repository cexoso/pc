angular.module('controller').controller('payCtrl',['$scope',function(s){
    
}]);