angular.module('services').constant("secret", "wxa5e2691d6ddde774");
