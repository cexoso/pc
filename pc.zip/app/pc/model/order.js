angular.module('services').service("mOrder",['$http','$q',function($http,$q){
    var obj=Object.create({});
    return obj;
}]);